local function BuiltEntity(event)
	if (string.match(event.entity.name, "omega--drill") ~= nil) then
		local e = event.entity
		local s = e.surface
		local X = e.position.x
		local Y = e.position.y
		chest = e.surface.find_entity("omega-chest",{X, Y})
		if chest ~= nil then
			return
		end
    local l = s.create_entity{name = "omega-chest", position = {X,Y}, force= e.force}
		l.destructible = false
		l.minable = false
	end

end


local function MinedEntity(event)
	if (string.match(event.entity.name, "omega--drill") ~= nil) then
		local b = event.entity
		local X = b.position.x
		local Y = b.position.y
		chest = b.surface.find_entity("omega-chest",{X, Y})
		if chest ~= nil then
			b.surface.spill_inventory{position=b.position,inventory=chest.get_inventory(defines.inventory.chest),force=b.force}
			chest.destroy()
		end
	end

end

local function OrphanBox(event)
--	game.print(event)
    if (event.entity == nil) then return end
	if not (event.entity.name == "omega-chest") then return end
--	event.entity.destructible = true
--	event.entity.minable = true
--	event.entity.order_deconstruction(event.entity.force)
	
	local b = event.entity
	local X = b.position.x
	local Y = b.position.y
	drill = b.surface.find_entities_filtered{type = "mining-drill", position = {X, Y}}
	if (drill[1] == nil) then b.surface.spill_inventory{position=b.position,inventory=b.get_inventory(defines.inventory.chest),force=b.force} b.destroy() end
end

--local function OnRobotPreMined(event)
--	if(event.entity and event.entity.valid and (string.match(event.entity.name, "omega--drill") ~= nil)) then
--		local b = event.entity
--		local X = b.position.x
--		local Y = b.position.y
--		local chest = b.surface.find_entity("omega-chest",{X, Y})
--		if chest == nil then return end
		
--		chest.destructible = true
--		chest.minable = true
--		chest.order_deconstruction(event.robot.force)
		
--		local chestInv = chest.get_inventory(defines.inventory.chest)
--		if chestInv and not chestInv.is_empty() then
--			local robotInventory = event.robot.get_inventory(defines.inventory.robot_cargo)
--			local robotSize = 1 + event.robot.force.worker_robots_storage_bonus
--			if robotInventory.is_empty() then
--				-- Find something to give to the robot. Otherwise the robot remains empty when the event returns, and it will finish mining the entity
--				for i=1, #chestInv do
--					local stack = chestInv[i]
--					if stack.valid_for_read then
					--game.print("Giving robot cargo stack: "..stack.name.." : "..stack.count)
--						local inserted = robotInventory.insert{name=stack.name, count=math.min(stack.count, robotSize), quality=stack.quality}
--						chestInv.remove{name=stack.name, count=inserted, quality=stack.quality}
--						if not robotInventory.is_empty() then
--							break
--						end
--					end
--				end
--			end
--		end
--	end
--	if(event.entity and event.entity.valid and event.entity.name == "omega-chest")then
--		chest = event.entity
--		local chestInv = chest.get_inventory(defines.inventory.chest)
--		if chestInv and chestInv.is_empty() then
--			chest.destructible = false
--			chest.minable = false
--			chest.cancel_deconstruction(event.robot.force)
--			return
--		end
--		if chestInv and not chestInv.is_empty() then
--			local robotInventory = event.robot.get_inventory(defines.inventory.robot_cargo)
--			local robotSize = 1 + event.robot.force.worker_robots_storage_bonus
--			if robotInventory.is_empty() then
				-- Find something to give to the robot. Otherwise the robot remains empty when the event returns, and it will finish mining the entity
--				for i=1, #chestInv do
--					local stack = chestInv[i]
--					if stack.valid_for_read then
					--game.print("Giving robot cargo stack: "..stack.name.." : "..stack.count)
--						local inserted = robotInventory.insert{name=stack.name, count=math.min(stack.count, robotSize), quality=stack.quality}
--						chestInv.remove{name=stack.name, count=inserted, quality=stack.quality}
--						if not robotInventory.is_empty() then
--							break
--						end
--					end
--				end
--			end
--		end
--	end
--end


script.on_event(defines.events.on_gui_opened, OrphanBox)

script.on_event(defines.events.on_robot_pre_mined , OnRobotPreMined)

script.on_event(defines.events.on_built_entity, BuiltEntity)
script.on_event(defines.events.on_robot_built_entity, BuiltEntity)
script.on_event(defines.events.script_raised_built, BuiltEntity)
script.on_event(defines.events.script_raised_revive, BuiltEntity)
script.on_event(defines.events.on_space_platform_built_entity, BuiltEntity)

script.on_event(defines.events.on_player_mined_entity , MinedEntity)
script.on_event(defines.events.on_entity_died , MinedEntity)
script.on_event(defines.events.on_robot_mined_entity , MinedEntity)
script.on_event(defines.events.script_raised_destroy , MinedEntity)
script.on_event(defines.events.on_space_platform_mined_entity , MinedEntity)