data:extend({
  {
    type = "car",
    name = "rotor-entity-_-",
    icon = "__base__/graphics/icons/car.png",
    icon_size = 64,
    flags = {"placeable-off-grid", "not-on-map"},
		render_layer = "air-object",
		final_render_layer = "air-object",
    minable = {mining_time = 1, result = "helicopter"},
    has_belt_immunity = true,
    max_health = 1500,
    hidden_in_factoriopedia = true,
    corpse = "medium-remnants",
    selection_box = {{0,0},{0,0}},
    collision_box = {{0,0},{0,0}},
    collision_mask = {layers = {}},
    energy_per_hit_point = 1,
    effectivity = 0.5,
    braking_power = "100kW",
    energy_source = {
      type = "burner",
      effectivity = 1,
      emissions = 0,
      fuel_inventory_size = 1,
    },
    consumption = "100kW",
    friction = 0.01,

    animation = {
      layers = {
        {
          priority = "high",
          width = 720,
          height = 600,
          frame_count = 1,
          direction_count = 64,
          shift = {0, -5.1},
          scale = 0.5,
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor-0.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor-1.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor-2.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor-3.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
          },
        },
      }
    },
    inventory_size = 0,
    rotation_speed = 0.005,
    weight = 50,
  },
  ------------shadow------------------
  {
    type = "car",
    name = "rotor-shadow-entity-_-",
    icon = "__base__/graphics/icons/car.png",
    icon_size = 64,
    flags = {"placeable-off-grid", "not-on-map"},
		-- render_layer = "air-object",
		-- final_render_layer = "air-object",
    minable = {mining_time = 1, result = "helicopter"},
    has_belt_immunity = true,
    max_health = 1500,
    hidden_in_factoriopedia = true,
    corpse = "medium-remnants",
    selection_box = {{0,0},{0,0}},
    collision_box = {{0,0},{0,0}},
    collision_mask = {layers= {}},
    energy_per_hit_point = 1,
    effectivity = 0.5,
    braking_power = "100kW",
    energy_source = {
      type = "burner",
      effectivity = 1,
      emissions = 0,
      fuel_inventory_size = 1,
    },
    consumption = "100kW",
    friction = 0.01,

    animation = {
      layers = {
        {
          priority = "very-low",
          width = 720,
          height = 600,
          frame_count = 1,
          draw_as_shadow = true,
          direction_count = 64,
          shift = {0.4, -0.5},
          scale = 0.5,
          animation_speed = 8,
          max_advance = 0.2,
          stripes =
          {
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor_shadow-0.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor_shadow-1.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor_shadow-2.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
            {
              filename = "__HelicopterRevival__/graphics/entities/heli/rotor_shadow-3.png",
              width_in_frames = 4,
              height_in_frames = 4,
            },
          },
        },
      }
    },
    inventory_size = 0,
    rotation_speed = 0.005,
    weight = 50,
  }
})
