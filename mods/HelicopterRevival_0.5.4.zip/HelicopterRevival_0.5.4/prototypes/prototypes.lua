require("util")
local scale = settings.startup["heli-gauge-scale"].value

--Equipment
data:extend({
	{
		type = "battery-equipment",
		name = "helicopter-remote-equipment",
		sprite =
		{
			filename = "__HelicopterRevival__/graphics/equipment/heli-remote-equipment.png",
			width = 128,
			height = 128,
			priority = "medium",
			scale = 0.5,
		},
		shape =
		{
			width = 2,
			height = 2,
			type = "full"
		},
		energy_source =
		{
			type = "electric",
			buffer_capacity = "2MJ",
			input_flow_limit = "1MW",
			output_flow_limit = "1MW",
			usage_priority = "tertiary"
		},
		categories = {"armor"}
	},
	-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	{-- Gunship grid
		type = "equipment-grid",
		name = "heli-equipment-grid",
		width = 8,
		height = 4,
		equipment_categories = {"armor"}
	},
})

local categories = {"armor"}
if mods["Krastorio2"] then
    categories = {}
    table.insert(categories, "kr-vehicle")
    table.insert(categories, "kr-vehicle-motor")
    table.insert(categories, "kr-vehicle-roboport")
end

if mods["space-exploration"] then
    table.insert(categories, "armor")
end

if mods["space-exploration"] and mods["Krastorio2"] then
    table.insert(categories, "reactor-equipment")
    table.insert(categories, "armor-shield")
    table.insert(categories, "armor-weapons")
    table.insert(categories, "belt-immunity")
end

data.raw["equipment-grid"]["heli-equipment-grid"].equipment_categories = categories

--Font
data:extend({
    {
        type = "font",
        name = "pixelated_normal",
        from = "pixelated",
        border = true,
        border_color = {0,0,0},
        size = 12,
    },
    {
        type = "font",
        name = "pixelated_small",
        from = "pixelated",
        border = true,
        border_color = {0,0,0},
        size = 9
    },
    {
        type = "sprite",
        name = "heli-map",
        filename = "__core__/graphics/icons/mip/map.png",
        priority = "extra-high-no-scale",
        size = 32,
        scale = 0.5,
        mipmap_count = 2,
        flags = {"gui-icon"},
        invert_colors = true,
    },
})

--Recipes
data:extend({
	{
		type = "recipe",
        name = "helicopter",
		enabled = false,
		energy_required = 60,
		ingredients = {
			{type = "item", name = "engine-unit", amount = 150},
			{type = "item", name = "steel-plate", amount = 150},
			{type = "item", name = "iron-gear-wheel", amount = 250},
			{type = "item", name = "processing-unit", amount = 250},
			{type = "item", name = "gun-turret", amount = 10},
			{type = "item", name = "rocket-launcher", amount = 10},
		},
		results = {{type = "item", name = "helicopter", amount = 1},},
	},
	{
		type = "recipe",
        name = "helicopter-remote-equipment",
		enabled = false,
		energy_required = 15,
		ingredients = {
			{type = "item", name = "processing-unit", amount = 125},
			{type = "item", name = "battery", amount = 20},
			{type = "item", name = "plastic-bar", amount = 40},
			{type = "item", name = "iron-stick", amount = 20},
		},
		results = {{type = "item", name = "helicopter-remote-equipment", amount = 1},}
	},
	{
		type = "recipe",
        name = "helicopter-pad",
		enabled = false,
		energy_required = 5,
		ingredients = {
			{type = "item", name = "refined-concrete", amount = 50},
		},
		results = {{type = "item", name = "helicopter-pad", amount = 1}},
	},
})

--Signals
data:extend({
	{
		type = "virtual-signal",
		name = "signal-heli-fuel-warning",
		icon = "__HelicopterRevival__/graphics/icons/fuel_warning.png",
		icon_size = 64,
		subgroup = "virtual-signal-number",
		order = "e[warnings]-[1]"
	},{
		type = "virtual-signal",
		name = "signal-heli-fuel-warning-critical",
		icon = "__core__/graphics/icons/alerts/fuel-icon-red.png",
		icon_size = 64,
		subgroup = "virtual-signal-number",
		order = "e[warnings]-[2]"
	},
})

--Sounds
data:extend({
	{
		type = "sound",
		name = "heli-fuel-warning",
		filename = "__HelicopterRevival__/sound/fuel_warning.ogg",
		volume = 0.5,
	},
	{
		type = "sound",
		name = "heli-cant-do",
		filename = "__core__/sound/cannot-build.ogg",
		volume = 1,
	},
})

--Technologies
data:extend({
    {
        type = "technology",
        name = "heli-remote-technology",
        icon = "__HelicopterRevival__/graphics/technology/heli-remote-technology.png",
        icon_size = 256,
        effects =
        {
            {
                type = "unlock-recipe",
                recipe = "helicopter-remote-equipment"
            },
        },
        prerequisites = {"heli-technology", "concrete", "processing-unit", "battery", "modular-armor"},
        unit =
        {
            count = 450,
            ingredients =
            {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 1},
                {"utility-science-pack", 1},
            },
            time = 45
        },
        order = "e-d"
    },

    {
        type = "technology",
        name = "heli-technology",
        icon = "__HelicopterRevival__/graphics/technology/heli-technology.png",
        icon_size = 256,
        effects =
        {
            {
                type = "unlock-recipe",
                recipe = "helicopter"
            },
            {
                type = "unlock-recipe",
                recipe = "helicopter-pad"
            },
        },
        prerequisites = {"automobilism", "processing-unit", "gun-turret", "rocketry"},
        unit =
        {
            count = 400,
            ingredients =
            {
                {"automation-science-pack", 1},
                {"logistic-science-pack", 1},
                {"chemical-science-pack", 2},
            },
            time = 30
        },
        order = "e-d"
    },
})

--Sprites
data:extend({
    {
        type = "sprite",
        name = "heli_to_player",
        filename = "__HelicopterRevival__/graphics/icons/to_player.png",
        priority = "medium",
        width = 64,
        height = 64,
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_to_map",
        filename = "__HelicopterRevival__/graphics/icons/map.png",
        priority = "medium",
        width = 64,
        height = 64,
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_to_pad",
        filename = "__HelicopterRevival__/graphics/icons/to_pad.png",
        priority = "medium",
        width = 64,
        height = 64,
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_stop",
        filename = "__HelicopterRevival__/graphics/icons/stop.png",
        priority = "medium",
        width = 64,
        height = 64,
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_gui_selected",
        filename = "__HelicopterRevival__/graphics/gui/selected.png",
        priority = "medium",
        width = 210,
        height = 210,
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_search_icon",
        filename = "__HelicopterRevival__/graphics/gui/search-icon.png",
        priority = "medium",
        width = 15,
        height = 15,
        shift = {-17, 1},
        flags = {"icon"},
    },
    {
        type = "sprite",
        name = "heli_void_128",
        filename = "__HelicopterRevival__/graphics/gui/gauges/void_128.png",
        priority = "medium",
        width = 128,
        height = 128,
    },
    {
        type = "sprite",
        name = "heli_gauge_fs",
        filename = "__HelicopterRevival__/graphics/gui/gauges/gauge_fs_hr.png",
        width = 256,
        height = 256,
        scale = 0.5 * scale,
        priority = "extra-high-no-scale",
    },
    {
        type = "sprite",
        name = "heli_gauge_fs_led_fuel",
        filename = "__HelicopterRevival__/graphics/gui/gauges/gauge_fs_led_fuel_hr.png",
        width = 256,
        height = 256,
        scale = 0.5 * scale,
        priority = "extra-high-no-scale",
    },
    {
        type = "sprite",
        name = "heli_gauge_hr",
        filename = "__HelicopterRevival__/graphics/gui/gauges/gauge_hr.png",
        width = 256,
        height = 256,
        scale = 0.5 * scale,
        priority = "extra-high-no-scale",
    },
})

gauge_pointers = {}
for i = 0, 127 do
	table.insert(gauge_pointers, {
		type = "sprite",
		name = "heli_gauge_pointer_" .. tostring(i),
		filename = "__HelicopterRevival__/graphics/gui/gauges/pointers/hr/pointer-" .. tostring(i) .. "-hr.png",
		priority = "medium",
        scale = 0.5 * scale,
		width = 256,
		height = 256,
	})
end
data:extend(gauge_pointers)
